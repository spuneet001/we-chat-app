//const { socket } = require('socket.io')
// Node server which handle the socket io connection
const io = require('socket.io')(8000)

const users = {};

io.on('connection', socket =>{
    //if new user joined the chat , let the other user know 
    socket.on('new-user-joined' , name=>{
        //console.log("New user", name)
        users[socket.id]=name;
        socket.broadcast.emit('user-joined' , name);
    });

    //if any user send the message so broadcast to all the user 
    socket.on('send' , message =>{
        socket.broadcast.emit('receive', {message : message , name : user[socket.id]})
    });

    // if any one left the chat , let the other know
    socket.on('disconnect' , message =>{
        socket.broadcast.emit('left', users[socket.id]);
        delete users[socket.id];
    });


})
